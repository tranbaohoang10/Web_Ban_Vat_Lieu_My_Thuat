package vn.edu.nlu.fit.mythuatshop.Model;

public class BestSellerChartPoint {
    private int productId;
    private String productName;
    private int soldQty;

    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getSoldQty() { return soldQty; }
    public void setSoldQty(int soldQty) { this.soldQty = soldQty; }
}
